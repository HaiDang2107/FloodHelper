import {
  Controller,
  Post,
  Body,
  Get,
  UseGuards,
  Res,
  Delete,
  Req,
  Query,
} from '@nestjs/common';
import type { Response, Request } from 'express';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import { GoogleAuthGuard } from './guards/google-auth.guard';
import { CurrentUser } from './decorators/current-user.decorator';
import {
  SignupDto,
  SigninDto,
  SignoutDto,
  ForgotPasswordDto,
  ResetPasswordDto,
  ChangePasswordDto,
  RefreshTokenDto,
  GoogleCallbackDto,
  SignupResponseDto,
  SigninResponseDto,
  SignoutResponseDto,
  GoogleSigninResponseDto,
  ForgotPasswordResponseDto,
  VerifyCodeResponseDto,
  ResetPasswordResponseDto,
  RefreshTokenResponseDto,
  VerifyCodeDto,
  ResendVerificationCodeDto,
} from './dto';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('signup')
  async signUp(
    @Body() registerDto: SignupDto,
  ): Promise<{ success: boolean; message: string }> {
    return this.authService.signUp(registerDto);
  }

  @Post('verify')
  async verifyCode(
    @Body() verifyCodeDto: VerifyCodeDto,
  ): Promise<VerifyCodeResponseDto> {
    return this.authService.verifyCode(verifyCodeDto);
  }

  @Post('resend-code')
  async resendVerificationCode(
    @Body() resendDto: ResendVerificationCodeDto,
  ): Promise<{ success: boolean; message: string }> {
    return this.authService.resendVerificationCode(resendDto);
  }

  @Post('signin')
  async signIn(
    @Body() signinDto: SigninDto,
    @Res({ passthrough: true }) response: Response,
    // @Res: Can thiệp vào Response (set header, ...) bởi vì bình thường, NestJS gửi response tự động
    // passthrough: Báo cho NestJS vẫn gửi response tự động sau khi can thiệp xong
    // Vì refresh token được cho vào cookie ==> xóa refresh_token trong body
  ): Promise<SigninResponseDto> {
    const result = await this.authService.signin(signinDto);
    response.cookie('refresh_token', result.data.tokens.refreshToken, {
      httpOnly: true,
      path: '/auth/token/refresh',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    });
    delete result.data.tokens.refreshToken;
    return result;
  }

  @Post('authority/signin')
  async signInAuthority(
    @Body() signinDto: SigninDto,
    @Res({ passthrough: true }) response: Response,
  ): Promise<SigninResponseDto> {
    const result = await this.authService.signinAuthority(signinDto);
    response.cookie('refresh_token', result.data.tokens.refreshToken, {
      httpOnly: true,
      path: '/auth/token/refresh',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });
    delete result.data.tokens.refreshToken;
    return result;
  }

  @Post('admin/signin')
  async signInAdmin(
    @Body() signinDto: SigninDto,
    @Res({ passthrough: true }) response: Response,
  ): Promise<SigninResponseDto> {
    const result = await this.authService.signinAdmin(signinDto);
    response.cookie('refresh_token', result.data.tokens.refreshToken, {
      httpOnly: true,
      path: '/auth/token/refresh',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });
    delete result.data.tokens.refreshToken;
    return result;
  }

  @UseGuards(JwtAuthGuard)
  @Delete('signout')
  async signOut(
    @CurrentUser() user,
    @Res({ passthrough: true }) response: Response,
    @Query('logoutAll') logoutAll?: boolean,
  ): Promise<SignoutResponseDto> {
    const result = await this.authService.logout({ logoutAll }, user);
    response.clearCookie('refresh_token', { path: '/auth/token/refresh' });
    return result;
  }
  
  @Post('password/forgot')
  async forgotPassword(
    @Body() forgotPasswordDto: ForgotPasswordDto,
  ): Promise<{ success: boolean; message: string }> {
    return this.authService.forgotPassword(forgotPasswordDto);
  }

  // @Post('password/verify')
  // async verifyPasswordReset(
  //   @Body() verifyDto: VerifyCodeDto,
  // ): Promise<{ resetToken: string }> {
  //   return this.authService.verifyPasswordReset(verifyDto);
  // }

  @UseGuards(JwtAuthGuard)
  @Post('password/reset')
  async resetPassword(
    @Body() resetPasswordDto: ResetPasswordDto,
    @CurrentUser() user: { accountId: string },
  ): Promise<{ success: boolean; message: string }> {
    return this.authService.resetPassword(resetPasswordDto, user);
  }

  @UseGuards(JwtAuthGuard)
  @Post('password/change')
  async changePassword(
    @Body() changePasswordDto: ChangePasswordDto,
    @CurrentUser() user: { accountId: string },
  ): Promise<{ success: boolean; message: string }> {
    return this.authService.changePassword(changePasswordDto, user);
  }

  @Post('token/refresh')
  async refreshToken(
    @Req() request: Request,
  ): Promise<RefreshTokenResponseDto> {
    // Get refresh token from cookie
    const refreshToken = request.cookies?.refresh_token;

    if (!refreshToken) {
      return {
        success: false,
        message: 'No refresh token provided',
        data: null,
      };
    }

    return this.authService.refreshToken({ refreshToken });
  }
}
