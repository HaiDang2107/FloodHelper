import {
  Injectable,
  Inject,
  UnauthorizedException,
  ConflictException,
  NotFoundException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { AccountState } from '../common/enum/accountState.enum';
import { Purpose } from '../common/enum/purpose.enum';
import { MailerService } from '@nestjs-modules/mailer';
import { CACHE_MANAGER } from '@nestjs/cache-manager';
import type { Cache } from 'cache-manager';
import { CachedOtp, JwtPayload } from './interfaces';
import { formatLocation } from '../common/location-format.util';
import {
  SignupDto,
  SigninDto,
  SignoutDto,
  ForgotPasswordDto,
  ResetPasswordDto,
  ChangePasswordDto,
  RefreshTokenDto,
  GoogleCallbackDto,
  SignupResponseDto,
  SigninResponseDto,
  SignoutResponseDto,
  GoogleSigninResponseDto,
  ForgotPasswordResponseDto,
  VerifyCodeResponseDto,
  ResetPasswordResponseDto,
  RefreshTokenResponseDto,
  VerifyCodeDto,
  ResendVerificationCodeDto,
} from './dto';
import { AuthRepository } from '../prisma/repositories';

@Injectable()
export class AuthService {
  constructor(
    private readonly authRepository: AuthRepository,
    private jwtService: JwtService,
    private mailerService: MailerService,
    @Inject(CACHE_MANAGER) private cacheManager: Cache,
  ) { }

  async signUp(
    registerDto: SignupDto,
  ): Promise<{ success: boolean; message: string }> {
    const { username, password, fullname, phoneNumber, ...rest } = registerDto;

    const existingAccount = await this.authRepository.findAccountByUsername(username);

    if (existingAccount) {
      if (
        existingAccount.state === AccountState.BANNED ||
        existingAccount.state === AccountState.ACTIVE
      ) {
        throw new ConflictException('Account already exists');
      }
      if (existingAccount.state === AccountState.INACTIVE) {
        throw new ConflictException('Account is not activated.');
      }
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await this.authRepository.createUserWithAccount({
      profiles: {
        create: {
          fullname,
          phoneNumber,
          nickname: rest.nickname,
          dob: rest.dob ? new Date(rest.dob) : undefined,
          originProvinceCode: rest.originProvinceCode,
          originWardCode: rest.originWardCode,
          residenceProvinceCode: rest.residenceProvinceCode,
          residenceWardCode: rest.residenceWardCode,
          dateOfIssue: rest.dateOfIssue ? new Date(rest.dateOfIssue) : undefined,
          dateOfExpire: rest.dateOfExpire ? new Date(rest.dateOfExpire) : undefined,
          occupation: rest.occupation,
          isCurrent: true,
        }
      },
      account: {
        create: {
          username,
          password: hashedPassword,
          state: AccountState.INACTIVE,
        },
      },
    });

    await this.createAndSendVerificationCode(
      user.account?.username,
      Purpose.CREATE_ACCOUNT,
    );

    return {
      success: true,
      message:
        'Registration successful. Please check your email to activate your account.',
    };
  }

  async createAndSendVerificationCode(
    account: any,
    type: Purpose,
  ): Promise<void> {
    const code = this.generateVerificationCode();

    const payload: CachedOtp = {
      code: code,
      type: type,
    };

    await this.cacheManager.set(
      `otp_${account}`,
      payload,
      parseInt(process.env.TTL_OTP || '300000'),
    );

    await this.mailerService.sendMail({
      to: account,
      subject: 'Mã xác thực',
      html: `<h1>Mã OTP của bạn là: ${code}</h1><p>Hết hạn sau 5 phút.</p>`,
    });
  }

  async verifyCode(
    verifyCodeDto: VerifyCodeDto,
  ): Promise<VerifyCodeResponseDto> {
    const { username, type, code } = verifyCodeDto;

    // Get verification code from Redis
    const storedPayload = await this.cacheManager.get<CachedOtp>(
      `otp_${username}`,
    );

    if (
      !storedPayload ||
      storedPayload.code !== code ||
      storedPayload.type !== type
    ) {
      throw new NotFoundException('Invalid verification code.');
    }

    await this.cacheManager.del(`otp_${username}`);

    const account = await this.authRepository.findAccountByUsernameWithDetailedUser(username);

    if (!account) {
      throw new NotFoundException('Account not found.');
    }

    if (type === Purpose.CREATE_ACCOUNT) {
      if (account.state !== AccountState.INACTIVE) {
        throw new ConflictException('Account is already activated or banned.');
      }

      // Activate account
      await this.authRepository.activateAccount(account.accountId);

      return {
        success: true,
        message: 'Account verification successful.',
      };
    } else {
      const role = account.user.role;

      return {
        success: true,
        resetToken: (
          await this.generateTokens(account.accountId, username, '', role, type)
        ).accessToken,
        message: 'Password reset verification successful.',
      };
    }
  }

  async resendVerificationCode(
    resendDto: ResendVerificationCodeDto,
  ): Promise<{ success: boolean; message: string }> {
    const { username, type } = resendDto;
    const account = await this.authRepository.findAccountByUsername(username);

    if (!account) {
      throw new NotFoundException('Account does not exist.');
    }

    // if (account.state !== AccountState.INACTIVE) {
    //   throw new ConflictException('Account is already activated or banned.');
    // }

    if (type === Purpose.CREATE_ACCOUNT) {
      // For account creation, account must be INACTIVE
      if (account.state !== AccountState.INACTIVE) {
        throw new ConflictException('Account is already activated or banned.');
      }
    } else if (type === Purpose.RESET_PASSWORD) {
      // For password reset, account must be ACTIVE
      this.validateAccountState(account);
    }

    await this.createAndSendVerificationCode(account.username, type);

    return { success: true, message: 'Verification code has been sent again.' };
  }

  private generateVerificationCode(length = 6): string {
    return Math.random()
      .toString(10)
      .substring(2, 2 + length);
  }

  private validateAccountState(account: any): void {
    if (account.state === AccountState.BANNED) {
      const message = 'Account is banned.';
      throw new ConflictException(message);
    }

    if (account.state === AccountState.INACTIVE) {
      const message = 'Account is not activated.';
      throw new ConflictException(message);
    }
  }

  async signin(signinDto: SigninDto): Promise<SigninResponseDto> {
    return this.signinInternal(signinDto);
  }

  async signinAuthority(signinDto: SigninDto): Promise<SigninResponseDto> {
    return this.signinInternal(signinDto, 'AUTHORITY');
  }

  async signinAdmin(signinDto: SigninDto): Promise<SigninResponseDto> {
    return this.signinInternal(signinDto, 'ADMIN');
  }

  private async signinInternal(
    signinDto: SigninDto,
    requiredRole?: string,
  ): Promise<SigninResponseDto> {
    const { username, password, deviceId } = signinDto;

    const account = await this.authRepository.findAccountByUsernameWithDetailedUser(
      username,
    );

    if (!account) {
      throw new UnauthorizedException('User not found!');
    }

    const isPasswordMatching = await bcrypt.compare(password, account.password);
    if (!isPasswordMatching) {
      throw new UnauthorizedException('Incorrect password.');
    }

    // Validate account state before allowing login
    this.validateAccountState(account);

    if (requiredRole && !account.user.role.includes(requiredRole)) {
      throw new UnauthorizedException('Insufficient role for this endpoint.');
    }

    const tokens = await this.generateTokens(
      account.accountId,
      username,
      deviceId,
      account.user.role,
      Purpose.SIGN_IN,
    );
    await this.updateRefreshToken(
      account.accountId,
      tokens.refreshToken,
      deviceId,
      account.user.role,
    );


    const user = account.user;
    const profile = user.profiles?.find(p => p.isCurrent) || { fullname: '', phoneNumber: '', nickname: '', avatarUrl: '', gender: null, dob: null, originProvinceCode: null, originWardCode: null, residenceProvinceCode: null, residenceWardCode: null, originProvince: null, originWard: null, residenceProvince: null, residenceWard: null, dateOfIssue: null, dateOfExpire: null, citizenId: null, frontCitizenIdCardImageUrl: null, occupation: null };
    const userWithProfile = {
      ...user,
      fullname: profile.fullname || '',
      phoneNumber: profile.phoneNumber || '',



      nickname: profile.nickname ?? '',
      avatarUrl: profile.avatarUrl ?? '',
      gender: profile.gender,
      dob: profile.dob,
      originProvinceCode: profile.originProvinceCode,
      originWardCode: profile.originWardCode,
      residenceProvinceCode: profile.residenceProvinceCode,
      residenceWardCode: profile.residenceWardCode,
      originProvince: profile.originProvince,
      originWard: profile.originWard,
      residenceProvince: profile.residenceProvince,
      residenceWard: profile.residenceWard,
      dateOfIssue: profile.dateOfIssue,
      dateOfExpire: profile.dateOfExpire,
      citizenId: profile.citizenId,
      frontCitizenIdCardImageUrl: profile.frontCitizenIdCardImageUrl ?? null,
      occupation: profile.occupation ?? null,
    };

    return {
      success: true,
      message: 'Sign in successful',
      data: {


        user: {
          userId: user.userId,
          name: userWithProfile.fullname,
          displayName: userWithProfile.nickname,
          phoneNumber: userWithProfile.phoneNumber,
          role: user.role,
          avatarUrl: userWithProfile.avatarUrl,
          gender: userWithProfile.gender,
          dob: userWithProfile.dob,
          placeOfOrigin: formatLocation(
            userWithProfile.originWard,
            userWithProfile.originProvince,
          ),
          placeOfResidence: formatLocation(
            userWithProfile.residenceWard,
            userWithProfile.residenceProvince,
          ),


          originProvinceCode: userWithProfile.originProvinceCode,
          originProvinceName: userWithProfile.originProvince?.name,
          originWardCode: userWithProfile.originWardCode,
          originWardName: userWithProfile.originWard?.name,
          residenceProvinceCode: userWithProfile.residenceProvinceCode,
          residenceProvinceName: userWithProfile.residenceProvince?.name,
          residenceWardCode: userWithProfile.residenceWardCode,
          residenceWardName: userWithProfile.residenceWard?.name,
          dateOfIssue: userWithProfile.dateOfIssue,
          dateOfExpire: userWithProfile.dateOfExpire,
          citizenId: userWithProfile.citizenId,
          frontCitizenIdCardImageUrl: userWithProfile.frontCitizenIdCardImageUrl,
          occupation: userWithProfile.occupation,
          showCharityCampaignLocations: user.showCharityCampaignLocations,
        },


        tokens: {
          accessToken: tokens.accessToken,
          refreshToken: tokens.refreshToken,
          expiresIn: tokens.accessTokenExpiresIn,
        },
      },
    };

  }

  private async generateTokens(
    accountId: string,
    username: string,
    deviceId: string,
    roles: string[],
    purpose: Purpose,
  ) {
    const payload: JwtPayload = {
      sub: accountId,
      username,
      deviceId,
      roles,
      purpose: purpose,
    };

    let refreshToken = '';

    if (purpose === Purpose.REFRESH_TOKEN || purpose === Purpose.SIGN_IN) {
      const rtExpiresIn = process.env.RT_EXPIRES_IN || '7d';

      refreshToken = this.jwtService.sign(
        payload as any,
        {
          secret: process.env.RT_SECRET || 'rt-secret',
          expiresIn: rtExpiresIn,
        } as any,
      );
    }

    const atExpiresIn = process.env.AT_EXPIRES_IN || '15m';

    const accessToken = this.jwtService.sign(
      payload as any,
      {
        secret: process.env.AT_SECRET || 'at-secret',
        expiresIn: atExpiresIn,
      } as any,
    );

    return {
      accessToken,
      refreshToken,
      accessTokenExpiresIn: this.convertToSeconds(atExpiresIn),
    };
  }

  private convertToSeconds(timeString: string): number {
    const regex = /^(\d+)([smhd])$/;
    const match = timeString.match(regex);

    if (!match) return 900; // Default 15 minutes

    const value = parseInt(match[1]);
    const unit = match[2];

    switch (unit) {
      case 's':
        return value;
      case 'm':
        return value * 60;
      case 'h':
        return value * 60 * 60;
      case 'd':
        return value * 60 * 60 * 24;
      default:
        return 900;
    }
  }

  private async updateRefreshToken(
    accountId: string,
    refreshToken: string,
    deviceId: string,
    role: string[],
  ) {
    const hashedRefreshToken = await bcrypt.hash(refreshToken, 10);
    const expireAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
    const roleString = role.join(',');

    await this.authRepository.upsertSession({
      accountId,
      deviceId,
      refreshToken: hashedRefreshToken,
      expireAt,
      role: roleString,
    });
  }

  async logout(logoutDto: SignoutDto, user: any): Promise<SignoutResponseDto> {
    const { logoutAll } = logoutDto;
    let deletedSessions;

    if (logoutAll) {
      // Delete all sessions for this account
      deletedSessions = await this.authRepository.deleteSessionsByAccount(user.accountId);
    } else {
      // Delete only the session for this specific device
      deletedSessions = await this.authRepository.deleteSessionByAccountAndDevice(
        user.accountId,
        user.deviceId,
      );
    }

    return {
      success: true,
      message: 'Logout successful',
      data: {
        loggedOutSessions: deletedSessions.count,
      },
    };
  }

  // async initiateGoogleLogin(): Promise<string> {
  //   // This method is not needed with Passport strategy
  //   // The redirect is handled by GoogleAuthGuard
  //   return 'Use GET /auth/google to initiate Google OAuth flow';
  // }

  async handleGoogleCallback(
    googleUser: any,
    deviceId?: string,
  ): Promise<GoogleSigninResponseDto> {
    const { googleId, email, firstName, lastName, picture } = googleUser;

    // Check if user exists by email or googleId
    let accountWithUser = await this.authRepository.findAccountByEmailOrProviderId(
      email,
      googleId,
    );

    let isNewUser = false;

    if (!accountWithUser) {
      // Create new user with Google account
      isNewUser = true;
      const newUser = await this.authRepository.createUserWithAccount({
        profiles: {
          create: {
            fullname: `${firstName} ${lastName}`,
            nickname: `${firstName} ${lastName}`,
            phoneNumber: email, // Using email as phoneNumber placeholder
            avatarUrl: picture,
            isCurrent: true,
          }
        },
        account: {
          create: {
            username: email,
            password: '', // No password for OAuth users
            state: AccountState.ACTIVE,
          },
        },
      });

      // Re-fetch to get proper structure
      accountWithUser = await this.authRepository.findAccountByIdWithUser(
        newUser.account!.accountId,
      );
    }

    if (!accountWithUser) {
      throw new UnauthorizedException('Failed to create or retrieve account');
    }

    if (accountWithUser.state !== AccountState.ACTIVE) {
      throw new UnauthorizedException('Account is not active');
    }

    // Generate tokens
    const tokens = await this.generateTokens(
      accountWithUser.accountId,
      accountWithUser.username,
      deviceId || 'google-oauth',
      accountWithUser.user.role,
      Purpose.USE_OTHER_SERVICES,
    );

    // Update refresh token in session
    await this.updateRefreshToken(
      accountWithUser.accountId,
      tokens.refreshToken,
      deviceId || 'google-oauth',
      accountWithUser.user.role,
    );

    const user = accountWithUser.user;
    const profile = user.profiles?.find((p: any) => p.isCurrent) || user.profiles?.[0] || {} as any;
    return {
      success: true,
      message: 'Google login successful',
      data: {
        user: {
          userId: user.userId,
          name: profile.fullname || '',
          phoneNumber: profile.phoneNumber || '',
          role: user.role,
        },

        tokens: {
          accessToken: tokens.accessToken,
          refreshToken: tokens.refreshToken,
          expiresIn: tokens.accessTokenExpiresIn,
        },
        session: {
          sessionId: 'google-session',
          expireAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        },
        isNewUser,
      },
    };
  }

  async forgotPassword(
    forgotPasswordDto: ForgotPasswordDto,
  ): Promise<{ success: boolean; message: string }> {
    const { username } = forgotPasswordDto;
    const account = await this.authRepository.findAccountByUsername(username);

    if (!account) {
      throw new NotFoundException('Account does not exist.');
    }

    this.validateAccountState(account);

    await this.createAndSendVerificationCode(
      account.username,
      Purpose.RESET_PASSWORD,
    );

    return {
      success: true,
      message: 'Password reset request has been sent. Please check your email.',
    };
  }

  // verifyPasswordReset removed - use verifyCode() with Purpose.RESET_PASSWORD instead

  async resetPassword(
    resetPasswordDto: ResetPasswordDto,
    user: { accountId: string },
  ): Promise<{ success: boolean; message: string }> {
    const { newPassword } = resetPasswordDto;
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await this.authRepository.updateAccountPassword(user.accountId, hashedPassword);

    return { success: true, message: 'Password has been reset successfully.' };
  }

  async changePassword(
    changePasswordDto: ChangePasswordDto,
    user: { accountId: string },
  ): Promise<{ success: boolean; message: string }> {
    const { oldPassword, newPassword } = changePasswordDto;
    const account = await this.authRepository.findAccountByIdWithUser(
      user.accountId,
    );

    if (!account) {
      throw new NotFoundException('Account not found.');
    }

    const isOldPasswordMatching = await bcrypt.compare(
      oldPassword,
      account.password,
    );
    if (!isOldPasswordMatching) {
      throw new UnauthorizedException('Old password is incorrect.');
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await this.authRepository.updateAccountPassword(user.accountId, hashedPassword);

    return { success: true, message: 'Password changed successfully.' };
  }

  async refreshToken(
    refreshTokenDto: RefreshTokenDto,
  ): Promise<RefreshTokenResponseDto> {
    try {
      // Verify refresh token JWT signature and extract payload
      const payload = this.jwtService.verify(refreshTokenDto.refreshToken, {
        secret: process.env.RT_SECRET || 'rt-secret',
      });

      // Find session by accountId + deviceId (unique per device)
      // This is more efficient than findMany + loop
      const session = await this.authRepository.findSessionForRefresh(
        payload.sub,
        payload.deviceId,
      );

      if (!session) {
        return {
          success: false,
          message: 'Session not found or expired',
          data: null,
        };
      }

      const isRefreshTokenMatching = await bcrypt.compare(
        refreshTokenDto.refreshToken,
        session.refreshToken,
      );

      if (!isRefreshTokenMatching) {
        return {
          success: false,
          message: 'Invalid refresh token',
          data: null,
        };
      }

      // Check if account is still active
      if (session.account.state !== 'ACTIVE') {
        return {
          success: false,
          message: 'Account is not active',
          data: null,
        };
      }

      // Generate only a new access token, keep existing refresh token unchanged.
      const newTokens = await this.generateTokens(
        session.account.accountId,
        session.account.username,
        session.deviceId || '',
        session.account.user.role,
        Purpose.USE_OTHER_SERVICES,
      );

      return {
        success: true,
        message: 'Token refreshed successfully',
        data: {
          tokens: {
            accessToken: newTokens.accessToken,
            expiresIn: newTokens.accessTokenExpiresIn,
          },
        },
      };
    } catch (error) {
      return {
        success: false,
        message: 'Invalid refresh token',
        data: null,
      };
    }
  }
}
