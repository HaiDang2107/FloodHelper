export class SendRequestDto {}
