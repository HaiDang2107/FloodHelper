// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'charity_campaign_view_model.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$charityCampaignViewModelHash() =>
    r'9614bfc4a1887c1284c44c971572802e79844553';

/// See also [CharityCampaignViewModel].
@ProviderFor(CharityCampaignViewModel)
final charityCampaignViewModelProvider =
    AutoDisposeNotifierProvider<
      CharityCampaignViewModel,
      CharityCampaignState
    >.internal(
      CharityCampaignViewModel.new,
      name: r'charityCampaignViewModelProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$charityCampaignViewModelHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$CharityCampaignViewModel = AutoDisposeNotifier<CharityCampaignState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
