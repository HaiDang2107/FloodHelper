// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'account_creation.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$accountCreationViewModelHash() =>
    r'85166a60e6176bbf0e05d59a5b9d638999debac9';

/// See also [AccountCreationViewModel].
@ProviderFor(AccountCreationViewModel)
final accountCreationViewModelProvider =
    AutoDisposeNotifierProvider<
      AccountCreationViewModel,
      AccountCreationState
    >.internal(
      AccountCreationViewModel.new,
      name: r'accountCreationViewModelProvider',
      debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
          ? null
          : _$accountCreationViewModelHash,
      dependencies: null,
      allTransitiveDependencies: null,
    );

typedef _$AccountCreationViewModel = AutoDisposeNotifier<AccountCreationState>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
