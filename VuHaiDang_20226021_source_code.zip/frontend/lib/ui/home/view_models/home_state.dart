part of 'home_view_model.dart';

enum MapType { transport, weather }

enum HomeUiEventType { info, success, error }

enum HomePinType { me, friend, victim, campaign }

class HomeCampaignLocationPin {
  final String campaignId;
  final String campaignName;
  final String destination;
  final LatLng position;

  const HomeCampaignLocationPin({
    required this.campaignId,
    required this.campaignName,
    required this.destination,
    required this.position,
  });
}

class HomeMapPin {
  final String userId;
  final String fullname;
  final String avatarUrl;
  final LatLng position;
  final HomePinType pinType;
  final bool isSos;
  final bool? isOnline;
  final String? campaignId;
  final String? campaignDestination;
  final List<String> roles;
  final bool isFriend;

  const HomeMapPin({
    required this.userId,
    required this.fullname,
    required this.avatarUrl,
    required this.position,
    required this.pinType,
    required this.isSos,
    this.isOnline,
    this.campaignId,
    this.campaignDestination,
    this.roles = const [],
    this.isFriend = false,
  });
}

class HomePinBubbleData {
  final String title;
  final String userId;
  final String fullname;
  final HomePinType pinType;
  final bool canHandle;

  const HomePinBubbleData({
    required this.title,
    required this.userId,
    required this.fullname,
    required this.pinType,
    required this.canHandle,
  });
}

class HomeUiEvent { // HomeScreen listen HomeState, do đó khi HomeUIEvent thay đổi, sẽ có một SnackBar hiển thị
  final HomeUiEventType type;
  final String message;

  const HomeUiEvent({required this.type, required this.message});
}

class HomeState {
  final LatLng? currentPosition;
  final bool isLoading;
  final MapType selectedMapType;
  final bool isSosBroadcasting;
  final DistressSignalInput? sosData;
  final bool showStrangerLocation;
  final bool showPostLocation;
  final bool showCharityCampaignLocations;
  final String? selectedPinId;
  final String? errorMessage;
  final HomeUiEvent? uiEvent;

  final List<UserModel> nearbyUsers;
  final List<PostModel> posts;
  final List<AnnouncementModel> announcements;
  final int unreadAnnouncementsCount;

  final Map<String, FriendLocationUpdate> friendLocations;
  final Map<String, LatLng> victimLocations;
  final Map<String, String> victimFullnames;
  final Map<String, bool> victimIsOnline;
  final Map<String, LatLng> rescuerLocations;
  final Map<String, String> rescuerFullnames;
  final Map<String, bool> rescuerIsSos;
  final Map<String, bool> rescuerIsOnline;

  final List<FriendModel> friendsWithMapMode;
  final List<HomeCampaignLocationPin> campaignLocations;

  final String locationVisibility;

  const HomeState({
    this.currentPosition,
    this.isLoading = true,
    this.selectedMapType = MapType.transport,
    this.isSosBroadcasting = false,
    this.sosData,
    this.showStrangerLocation = true,
    this.showPostLocation = true,
    this.showCharityCampaignLocations = false,
    this.selectedPinId,
    this.errorMessage,
    this.uiEvent,
    this.nearbyUsers = const [],
    this.posts = const [],
    this.announcements = const [],
    this.unreadAnnouncementsCount = 0,
    this.friendLocations = const {},
    this.victimLocations = const {},
    this.victimFullnames = const {},
    this.victimIsOnline = const {},
    this.rescuerLocations = const {},
    this.rescuerFullnames = const {},
    this.rescuerIsSos = const {},
    this.rescuerIsOnline = const {},
    this.friendsWithMapMode = const [],
    this.campaignLocations = const [],
    this.locationVisibility = 'JUST_FRIEND',
  });

  HomeState copyWith({
    LatLng? currentPosition,
    bool? isLoading,
    MapType? selectedMapType,
    bool? isSosBroadcasting,
    DistressSignalInput? sosData,
    bool? showStrangerLocation,
    bool? showPostLocation,
    bool? showCharityCampaignLocations,
    String? selectedPinId,
    String? errorMessage,
    HomeUiEvent? uiEvent,
    bool clearSosData = false,
    bool clearUiEvent = false,
    bool clearSelectedPin = false,
    List<UserModel>? nearbyUsers,
    List<PostModel>? posts,
    List<AnnouncementModel>? announcements,
    int? unreadAnnouncementsCount,
    Map<String, FriendLocationUpdate>? friendLocations,
    Map<String, LatLng>? victimLocations,
    Map<String, String>? victimFullnames,
    Map<String, bool>? victimIsOnline,
    Map<String, LatLng>? rescuerLocations,
    Map<String, String>? rescuerFullnames,
    Map<String, bool>? rescuerIsSos,
    Map<String, bool>? rescuerIsOnline,
    List<FriendModel>? friendsWithMapMode,
    List<HomeCampaignLocationPin>? campaignLocations,
    String? locationVisibility,
  }) {
    return HomeState(
      currentPosition: currentPosition ?? this.currentPosition,
      isLoading: isLoading ?? this.isLoading,
      selectedMapType: selectedMapType ?? this.selectedMapType,
      isSosBroadcasting: isSosBroadcasting ?? this.isSosBroadcasting,
      sosData: clearSosData ? null : (sosData ?? this.sosData),
      showStrangerLocation: showStrangerLocation ?? this.showStrangerLocation,
      showPostLocation: showPostLocation ?? this.showPostLocation,
        showCharityCampaignLocations:
          showCharityCampaignLocations ?? this.showCharityCampaignLocations,
      selectedPinId: clearSelectedPin
          ? null
          : (selectedPinId ?? this.selectedPinId),
      errorMessage: errorMessage,
      uiEvent: clearUiEvent ? null : (uiEvent ?? this.uiEvent),
      nearbyUsers: nearbyUsers ?? this.nearbyUsers,
      posts: posts ?? this.posts,
      announcements: announcements ?? this.announcements,
      unreadAnnouncementsCount:
          unreadAnnouncementsCount ?? this.unreadAnnouncementsCount,
      friendLocations: friendLocations ?? this.friendLocations,
      victimLocations: victimLocations ?? this.victimLocations,
      victimFullnames: victimFullnames ?? this.victimFullnames,
      victimIsOnline: victimIsOnline ?? this.victimIsOnline,
      rescuerLocations: rescuerLocations ?? this.rescuerLocations,
      rescuerFullnames: rescuerFullnames ?? this.rescuerFullnames,
      rescuerIsSos: rescuerIsSos ?? this.rescuerIsSos,
      rescuerIsOnline: rescuerIsOnline ?? this.rescuerIsOnline,
      friendsWithMapMode: friendsWithMapMode ?? this.friendsWithMapMode,
      campaignLocations: campaignLocations ?? this.campaignLocations,
      locationVisibility: locationVisibility ?? this.locationVisibility,
    );
  }
}
