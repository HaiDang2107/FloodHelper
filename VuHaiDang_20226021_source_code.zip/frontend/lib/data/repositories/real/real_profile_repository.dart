import 'package:image_picker/image_picker.dart';

import '../../models/profile_model.dart';
import '../../services/profile_service.dart';
import '../profile_repository.dart';

/// Real implementation of ProfileRepository using ProfileService
class RealProfileRepository implements ProfileRepository {
  final ProfileService _profileService;

  RealProfileRepository({required ProfileService profileService}) 
      : _profileService = profileService;

  @override
  Future<ProfileModel> getProfile() async {
    return await _profileService.getProfile();
  }

  @override
  Future<ProfileModel> updateProfile(
    UpdateProfileDto dto, {
    XFile? avatar,
    XFile? frontCitizenId,
    XFile? backCitizenId,
    XFile? rescuerCertificate,
  }) async {
    return await _profileService.updateProfile(
      dto,
      avatar: avatar,
      frontCitizenId: frontCitizenId,
      backCitizenId: backCitizenId,
      rescuerCertificate: rescuerCertificate,
    );
  }

  @override
  Future<void> updateLocation({
    required double longitude,
    required double latitude,
  }) async {
    return await _profileService.updateLocation(
      longitude: longitude,
      latitude: latitude,
    );
  }

  @override
  Future<ProfileModel?> getUserById(String userId) async {
    return await _profileService.getUserById(userId);
  }

  @override
  Future<void> createRoleRequest({required String type}) async {
    await _profileService.createRoleRequest(type: type);
  }

  @override
  Future<List<ProfileRoleRequestModel>> getMyRoleRequests() async {
    return _profileService.getMyRoleRequests();
  }

  @override
  Future<List<ProfileUpdateRequestModel>> getMyProfileUpdateRequests() async {
    return _profileService.getMyProfileUpdateRequests();
  }

  @override
  Future<void> revokeProfileUpdateRequest(String requestId) async {
    await _profileService.revokeProfileUpdateRequest(requestId);
  }

  @override
  Future<String?> createProfileUpdateRequest({
    required Map<String, dynamic> body,
    XFile? avatar,
    XFile? frontCitizenId,
    XFile? backCitizenId,
    XFile? rescuerCertificate,
  }) async {
    return await _profileService.createProfileUpdateRequest(
      body: body,
      avatar: avatar,
      frontCitizenId: frontCitizenId,
      backCitizenId: backCitizenId,
      rescuerCertificate: rescuerCertificate,
    );
  }

  @override
  Future<void> revokeRoleRequest(String requestId) async {
    await _profileService.revokeRoleRequest(requestId);
  }
}
